﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite;

namespace WpPaySorter2
{
    class DBdata
    {
        #region public methods
        //Inserts Employee record into Employee table
        public static void InsertEmployee(string name, string position, double payRate)
        {
            SQLiteConnection db = new SQLiteConnection("Personnel.db3", true);
            db.CreateTable<Employee>();
            List<Employee> emp = new List<Employee>()
            {
                new Employee() { Name = name, Position = position, PayRate=(decimal)payRate },
            };
            db.InsertAll(emp);
        }

        //Returns the list filled with Employee records
        public static List<Employee> GetEmployee()
        {
            SQLiteConnection db = new SQLiteConnection("Personnel.db3", true);
            List<Employee> emList = new List<Employee>();
            emList = db.Table<Employee>().ToList();
            return emList;
        }
        #endregion
    }
}
