﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WpPaySorter2
{
    public enum ESortOrder
    {
        DESC,
        ASC,
    }
    public enum ESortFiled
    {
        Name,
        Position,
        PayRate
    }

    //MVVM class 
    class EmployeeData : INotifyPropertyChanged
    {
        private List<Employee> empList;

        public List<Employee> EmployeeList
        {
            get { return empList; }
            set { empList = value; OnPropertyChanged(); }
        }

        //Constructor - fills Employee list with db data
        public EmployeeData()
        {
            EmployeeList = new List<Employee>();
            if (!File.Exists("Personnel.db3"))
            {
                DBdata.InsertEmployee("Peter", "Manager", 30.50);
                DBdata.InsertEmployee("Tom", "Expert", 45.20);
                DBdata.InsertEmployee("Vu", "Manager", 70.25);
                DBdata.InsertEmployee("Yasir", "The Boss", 65.50);
                DBdata.InsertEmployee("Oksana", "MVVM specialist", 25.50);
                DBdata.InsertEmployee("Joe", "Manager", 70.25);
            }
            EmployeeList = DBdata.GetEmployee();
        }

        //Sorts the list by parameters
        public void SortData(ESortOrder order = ESortOrder.ASC, ESortFiled field = ESortFiled.PayRate)
        {
            IEnumerable<Employee> sortedEmployee;

            //Descending order
            if (order == ESortOrder.DESC)
            {
                switch (field)
                {
                    case ESortFiled.PayRate:
                        sortedEmployee = empList.OrderByDescending(em => em.PayRate);
                        break;
                    case ESortFiled.Name:
                        sortedEmployee = empList.OrderByDescending(em => em.Name);
                        break;
                    case ESortFiled.Position:
                        sortedEmployee = empList.OrderByDescending(em => em.Position);
                        break;
                    default:
                        sortedEmployee = empList.OrderByDescending(em => em.ID);
                        break;
                }
            }
            //Ascending order
            else
            {
                switch (field)
                {
                    case ESortFiled.PayRate:
                        sortedEmployee = empList.OrderBy(em => em.PayRate);
                        break;
                    case ESortFiled.Name:
                        sortedEmployee = empList.OrderBy(em => em.Name);
                        break;
                    case ESortFiled.Position:
                        sortedEmployee = empList.OrderBy(em => em.Position);
                        break;
                    default:
                        sortedEmployee = empList.OrderBy(em => em.ID);
                        break;
                }
            }
            //Employee list is sorted
            EmployeeList = sortedEmployee.ToList();
        }

        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName]string caller = null)
        {
            // make sure only to call this if the value actually changes
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(caller));
            }
        }
        #endregion
    }
}
